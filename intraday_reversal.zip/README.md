# 📊 Intraday Reversal Strategy Optimisation (SPY & QQQ)

This project implements and optimises a **mean-reversion intraday trading strategy** using `kdb+/q` and `Python`. The strategy detects sharp intraday drops (>1%) in the **S&P 500 (SPY)** or **Nasdaq 100 (QQQ)** by 1pm EST, then enters a long trade and manages the position with stop-loss, take-profit, and trailing-stop logic.

...