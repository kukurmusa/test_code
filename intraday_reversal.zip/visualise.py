# visualise.py - Python visual analysis of strategy results

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("combined_optimisation.csv")
sns.scatterplot(data=df, x="sharpe", y="totalPnL", hue="sym")
plt.title("Sharpe vs Total PnL (SPY vs QQQ)")
plt.grid(True)
plt.show()