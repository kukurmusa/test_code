import numpy as np
import pandas as pd

def generate_dummy_returns(seed=0):
    np.random.seed(seed)
    dates = pd.date_range(end=pd.Timestamp.today(), periods=252)
    returns = np.random.normal(loc=0, scale=0.01, size=len(dates))
    return pd.Series(returns, index=dates)

def get_dummy_exposures(n_factors=20, n_hedges=10):
    np.random.seed(42)
    B_b = np.random.randn(n_factors)
    B_h = np.random.randn(n_hedges, n_factors)
    A = np.random.randn(n_factors, n_factors)
    Cov_F = A @ A.T + np.eye(n_factors) * 0.1
    hedge_instruments = [f"Hedge_{i+1}" for i in range(n_hedges)]
    adv_data = np.random.uniform(5, 20, size=n_hedges)
    beta_data = np.random.uniform(0.8, 1.2, size=n_hedges)
    return B_b, B_h, Cov_F, hedge_instruments, adv_data, beta_data
