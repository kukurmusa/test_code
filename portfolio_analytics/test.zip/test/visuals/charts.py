import plotly.graph_objects as go
import pandas as pd

def plot_risk_bar_chart(df_risk_contrib):
    fig = go.Figure()
    fig.add_trace(go.Bar(x=df_risk_contrib['Factor'], y=df_risk_contrib['Before'], name='Before'))
    fig.add_trace(go.Bar(x=df_risk_contrib['Factor'], y=df_risk_contrib['After'], name='After'))
    fig.update_layout(barmode='group', title='Factor Risk Contribution')
    return fig

def plot_waterfall(df_risk_contrib):
    risk_diff = df_risk_contrib['Before'] - df_risk_contrib['After']
    fig = go.Figure(go.Waterfall(
        name="Risk Reduction",
        orientation="v",
        measure=["relative"] * len(risk_diff),
        x=df_risk_contrib['Factor'],
        y=risk_diff,
        connector={"line": {"color": "rgb(63, 63, 63)"}}
    ))
    fig.update_layout(title="Risk Contribution Reduction by Factor")
    return fig

def plot_exposure_heatmap(B_h, hedge_instruments, adv_data, beta_data):
    df = pd.DataFrame(B_h, index=hedge_instruments, columns=[f"F{i+1}" for i in range(B_h.shape[1])])
    df["ADV%"] = adv_data
    df["Beta"] = beta_data
    hovertext = [[f"Instrument: {inst}<br>Factor: {factor}<br>Exposure: {val:.4f}<br>ADV%: {df.loc[inst, 'ADV%']:.2f}<br>Beta: {df.loc[inst, 'Beta']:.2f}"
                  for factor, val in zip(df.columns[:-2], row[:-2])]
                 for inst, row in df.iterrows()]
    fig = go.Figure(data=go.Heatmap(
        z=df.iloc[:, :-2].values,
        x=df.columns[:-2],
        y=df.index,
        text=hovertext,
        hoverinfo='text',
        colorscale='RdBu',
        zmid=0,
        colorbar=dict(title="Exposure")
    ))
    fig.update_layout(title="Factor Exposure Heatmap (Hedge Instruments)", xaxis_nticks=len(df.columns[:-2]))
    return fig
