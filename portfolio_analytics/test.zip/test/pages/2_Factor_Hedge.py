# pages/2_Factor_Hedge.py
import streamlit as st
import pandas as pd

from data.dummy_inputs import get_dummy_exposures
from engine.optimiser import optimise_factor_hedge
from engine.risk_metrics import compute_risk_contributions, total_risk
from visuals.charts import plot_risk_bar_chart, plot_waterfall, plot_exposure_heatmap
from output.export_utils import download_hedge_results

st.title("📊 Factor-Based Hedge Optimisation")

# Sidebar constraints
max_hedges = st.sidebar.slider("Max Number of Hedge Instruments", 1, 10, 5)
max_weight = st.sidebar.slider("Max % Notional per Hedge", 0.01, 1.0, 0.2)

# Load dummy factor inputs
B_b, B_h, Cov_F, hedge_instruments, adv_data, beta_data = get_dummy_exposures()

# Optimise
weights, exposure_post = optimise_factor_hedge(B_b, B_h, Cov_F, max_hedges, max_weight)
risk_before = total_risk(B_b, Cov_F)
risk_after = total_risk(exposure_post, Cov_F)
contrib_before = compute_risk_contributions(B_b, Cov_F)
contrib_after = compute_risk_contributions(exposure_post, Cov_F)

df_weights = pd.DataFrame({"Instrument": hedge_instruments, "Weight": weights}).query("Weight > 0.0001")
df_summary = pd.DataFrame({
    "Metric": ["Total Risk Before", "Total Risk After", "Risk Reduction"],
    "Value": [risk_before, risk_after, risk_before - risk_after]
})
df_risk_contrib = pd.DataFrame({
    "Factor": [f"Factor_{i+1}" for i in range(len(B_b))],
    "Before": contrib_before,
    "After": contrib_after
})

# Output
st.subheader("Optimal Hedge Weights")
st.dataframe(df_weights)

st.subheader("📉 Risk Summary")
st.dataframe(df_summary)

st.subheader("🔥 Risk Contribution by Factor")
st.plotly_chart(plot_risk_bar_chart(df_risk_contrib), use_container_width=True)

st.subheader("🌊 Risk Reduction Waterfall")
st.plotly_chart(plot_waterfall(df_risk_contrib), use_container_width=True)

st.subheader("🧭 Hedge Instrument Exposure Heatmap")
st.plotly_chart(plot_exposure_heatmap(B_h, hedge_instruments, adv_data, beta_data), use_container_width=True)

download_hedge_results(df_weights, df_summary, df_risk_contrib)
