# pages/1_Returns_Hedge.py
import streamlit as st
import plotly.graph_objects as go
from data.dummy_inputs import generate_dummy_returns
from engine.returns_hedge import simulate_returns_hedge

st.title("📈 Returns-Based Hedge Simulation")

basket_returns = generate_dummy_returns(seed=42)
hedge_returns = generate_dummy_returns(seed=99)

result = simulate_returns_hedge(basket_returns, hedge_returns)

fig = go.Figure()
fig.add_trace(go.Scatter(x=basket_returns.index, y=result["basket"], name="Basket"))
fig.add_trace(go.Scatter(x=hedge_returns.index, y=result["hedge"], name="Hedge"))
fig.add_trace(go.Scatter(x=hedge_returns.index, y=result["hedged"], name="Hedged Basket"))
fig.update_layout(title="Cumulative Return Comparison", xaxis_title="Date", yaxis_title="Cumulative Return")

st.plotly_chart(fig, use_container_width=True)
st.write(f"**Simulated Tracking Error:** {result['tracking_error']:.4f}")
