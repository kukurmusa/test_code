import numpy as np
import pandas as pd

def simulate_returns_hedge(basket_returns, hedge_returns, basket_beta=1.0, hedge_beta=1.05):
    hedge_ratio = basket_beta / hedge_beta
    hedged_returns = basket_returns - hedge_ratio * hedge_returns
    tracking_error = np.std(basket_returns - hedged_returns)
    return {
        "basket": basket_returns.cumsum(),
        "hedge": hedge_returns.cumsum(),
        "hedged": hedged_returns.cumsum(),
        "tracking_error": tracking_error
    }
