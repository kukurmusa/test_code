import cvxpy as cp

def optimise_factor_hedge(B_b, B_h, Cov_F, max_hedges=5, max_weight=0.2):
    n_hedges = B_h.shape[0]
    w = cp.Variable(n_hedges)
    exposure_post = B_b + B_h.T @ w
    objective = cp.Minimize(cp.quad_form(exposure_post, Cov_F))
    constraints = [w >= 0, cp.sum(w) <= max_hedges * max_weight]
    cp.Problem(objective, constraints).solve()
    return w.value, exposure_post.value
