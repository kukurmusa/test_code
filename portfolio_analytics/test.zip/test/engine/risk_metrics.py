import numpy as np

def compute_risk_contributions(B, Cov_F):
    return np.multiply(B, Cov_F @ B)

def total_risk(B, Cov_F):
    return float(B.T @ Cov_F @ B)
