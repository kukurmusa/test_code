# Home.py
import streamlit as st

st.set_page_config(page_title="Hedge Analysis App", layout="wide")
st.title("🛡️ Hedge Analysis Dashboard")

st.markdown("""
Welcome to the multi-method hedge analysis tool. Use the sidebar to explore:
- **Returns-Based Hedging** for fast simulations
- **Factor-Based Hedging** for optimised risk control

Each module supports summary views, performance charts, and downloadable reports.
""")