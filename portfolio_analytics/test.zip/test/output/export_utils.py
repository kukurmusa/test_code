import streamlit as st
import pandas as pd
import io

def download_hedge_results(df_weights, df_summary, df_risk_contrib):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
        df_weights.to_excel(writer, sheet_name="Weights", index=False)
        df_summary.to_excel(writer, sheet_name="Summary", index=False)
        df_risk_contrib.to_excel(writer, sheet_name="RiskContrib", index=False)
        writer.save()
    st.download_button(
        label="⬇️ Download Hedge Report (Excel)",
        data=buffer.getvalue(),
        file_name="factor_hedge_report.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
